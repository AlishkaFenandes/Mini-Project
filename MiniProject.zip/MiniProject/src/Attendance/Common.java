package Attendance;

import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Common {
	JButton logoutButton = new JButton("Logout");
	JLabel x = new JLabel("X");
	JLabel back = new JLabel("< BACK");
	JPanel panel = new  JPanel();
	JLabel date = new JLabel("Date : ");
	JLabel classes = new JLabel("Class : ");
	final JLabel txt = new JLabel("");
	JButton view = new JButton("VIEW");
	JButton absent = new JButton("ABSENT");
	JButton present = new JButton("PRESENT");
	JButton submit = new JButton("SUBMIT");
	
	JLabel id = new JLabel("Id : ");
	JLabel user = new JLabel("Username : ");
	JLabel nm = new JLabel("Name : ");
	JLabel pass = new JLabel("Password : ");
	final JButton togglePasswordButton = new JButton("Show Password");
	final JButton save = new JButton("SAVE");

	JButton delete = new JButton("DELETE");
	
	
   
}
