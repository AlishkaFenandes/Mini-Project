package Attendance;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class StudentView {

    Connection con;
    JFrame frame = new JFrame();
    DefaultTableModel model = new DefaultTableModel();


    public void stView(final int id) throws SQLException {
        //logout
        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(30, 7, 80, 20);
        logoutButton.setFont(new Font("Poppins", Font.BOLD, 12));
        logoutButton.setBackground(Color.decode("#0000"));
        logoutButton.setForeground(Color.decode("#FFFFFF"));
        frame.add(logoutButton);
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); 
                Login login = new Login();
                login.loginView();
            }
        });
        
        //CLOSE
        JLabel x = new JLabel("X");
        x.setForeground(Color.decode("#37474F"));
        x.setBounds(965, 10, 100, 20);
        x.setFont(new Font("Poppins", Font.BOLD, 16));
        frame.add(x);
        x.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.exit(0);
            }
        });
        
        

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 1000, 35);
        panel.setBackground(Color.decode("#FFFFFF"));
        frame.add(panel);
        
        
        JLabel welcome = new JLabel("Welcome " + getUser(id) + ",");
        welcome.setForeground(Color.decode("#FFFFFF"));
        welcome.setBounds(10, 50, 250, 20);
        welcome.setFont(new Font("Poppin", Font.BOLD, 14));
        frame.add(welcome);
       
        //table
        JTable table = new JTable();
        model = (DefaultTableModel) table.getModel();
        model.addColumn("DATE");
        model.addColumn("STATUS");
        JScrollPane scPane = new JScrollPane(table);
        scPane.setBounds(500, 50, 480, 525);
        table.setFont(new Font("Poppins", Font.BOLD, 16));
        table.setRowHeight(50);
        frame.add(scPane);


        
        //info
        JLabel totalclass = new JLabel("Total Days : ");
        totalclass.setBounds(140, 160, 250, 20);
        totalclass.setForeground(Color.decode("#FFFFFF"));
        totalclass.setFont(new Font("Poppins", Font.BOLD, 16));
        frame.add(totalclass);
        JLabel ttbox = new JLabel("");
        ttbox.setBounds(275, 160, 250, 20);
        ttbox.setForeground(Color.decode("#FFFFFF"));
        ttbox.setFont(new Font("Poppins", Font.BOLD, 16));
        frame.add(ttbox);
        JLabel classAtt = new JLabel("Days Attended : ");
        classAtt.setBounds(140, 260, 250, 20);
        classAtt.setForeground(Color.decode("#FFFFFF"));
        classAtt.setFont(new Font("Poppins", Font.BOLD, 16));
        frame.add(classAtt);
        JLabel atbox = new JLabel("");
        atbox.setBounds(320, 260, 250, 20);
        atbox.setForeground(Color.decode("#FFFFFF"));
        atbox.setFont(new Font("Poppinsn", Font.BOLD, 16));
        frame.add(atbox);
        JLabel classAbs = new JLabel("Days Missed : ");
        classAbs.setBounds(140, 360, 250, 20);
        classAbs.setForeground(Color.decode("#FFFFFF"));
        classAbs.setFont(new Font("Poppins", Font.BOLD, 16));
        frame.add(classAbs);
        JLabel mtbox = new JLabel("");
        mtbox.setBounds(280, 360, 250, 20);
        mtbox.setForeground(Color.decode("#FFFFFF"));
        mtbox.setFont(new Font("Poppins", Font.BOLD, 16));
        frame.add(mtbox);
        JLabel AttPer = new JLabel("Attendance Percentage : ");
        AttPer.setBounds(140, 460, 300, 20);
        AttPer.setForeground(Color.decode("#FFFFFF"));
        AttPer.setFont(new Font("Poppins", Font.BOLD, 16));
        frame.add(AttPer);
        JLabel prbox = new JLabel("");
        prbox.setBounds(360, 465, 250, 20);
        prbox.setForeground(Color.decode("#FFFFFF"));
        prbox.setFont(new Font("Times New Roman", Font.BOLD, 16));
        frame.add(prbox);
        
        
        //setvalue
        int[] arr = stat(id); // Change to use the correct student ID
        ttbox.setText(String.valueOf(arr[0]));
        atbox.setText(String.valueOf(arr[1]));
        mtbox.setText(String.valueOf(arr[2]));
        prbox.setText(String.valueOf(arr[3]) + "%");
        tblupdt(id); 
        
        
        
        frame.setSize(1000, 600);
        frame.setResizable(false);
        frame.setLayout(null);
        frame.setUndecorated(true);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setFocusable(true);
        frame.getContentPane().setBackground(Color.decode("#25CEDE"));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
    }

    public String getUser(int id) throws SQLException {
        // ENTER PORT, USER, PASSWORD.
        String url = "jdbc:mysql://localhost:3306/attendance";
        String user = "root";
        String pass = "alishka";
        con = DriverManager.getConnection(url, user, pass);
        String str = "SELECT name FROM user WHERE id = " + id;
        Statement stm = con.createStatement();
        ResultSet rst = stm.executeQuery(str);
        rst.next();
        return rst.getString("name");
    }

    public void tblupdt(int id) {
        try {
            ResultSet res = dbSearch(id);
            for (int i = 0; res.next(); i++) {
                model.addRow(new Object[0]);
                model.setValueAt(res.getString("dt"), i, 0);
                model.setValueAt(res.getString("status"), i, 1);
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
    }

    public int[] stat(int id) throws SQLException {
        String str = "SELECT COUNT(*) AS pre FROM attend WHERE stid = " + id + " AND status = 'Present'";
        String str2 = "SELECT COUNT(*) AS abs FROM attend WHERE stid = " + id + " AND status = 'Absent'";
        int[] x = new int[4];
        Statement stm = con.createStatement();
        ResultSet rst = stm.executeQuery(str);
        rst.next();
        x[1] = rst.getInt("pre");
        rst = stm.executeQuery(str2);
        rst.next();
        x[2] = rst.getInt("abs");
        x[0] = x[1] + x[2];
        x[3] = (x[1] * 100) / x[0];
        tblupdt(id);
        return x;
    }

    public ResultSet dbSearch(int id) throws SQLException {
        String str1 = "SELECT * from attend where stid = " + id + " ORDER BY dt desc";
        Statement stm = con.createStatement();
        ResultSet rst = stm.executeQuery(str1);
        return rst;
    }

    public void displayAttendanceDetails(int id, String selectedClass) {
        try {
            String query = "SELECT dt, status FROM attend WHERE stid = ? AND class = ? ORDER BY dt DESC";
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, id);
            statement.setString(2, selectedClass);
            ResultSet resultSet = statement.executeQuery();

            model.setRowCount(0); // Clear existing rows

            while (resultSet.next()) {
                model.addRow(new Object[]{
                        resultSet.getString("dt"),
                        resultSet.getString("status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Updated method to retrieve class names from the database
    public String[] classEt() throws SQLException {
        String str1 = "SELECT name from class";
        Statement stm = con.createStatement();
        ResultSet rst = stm.executeQuery(str1);
        String[] rt = new String[25];
        int i = 0;
        while (rst.next()) {
            rt[i] = rst.getString("name");
            i++;
        }
        return rt;
    }
}
