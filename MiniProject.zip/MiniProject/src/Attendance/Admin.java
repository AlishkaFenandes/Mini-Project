package Attendance;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class Admin extends Common{

	DefaultTableModel model = new DefaultTableModel();
	Font text = new Font("Poppins", Font.PLAIN, 14);
	Connection con;
	int check;
	JButton edit;
	JButton delete;
	JButton add;
	
	public void adminView() throws NumberFormatException, SQLException {
		final JFrame frame = new JFrame();
		Font btn = new Font("Poppins", Font.BOLD, 14);
		
		//CLOSE
		x.setForeground(Color.decode("#37474F"));
		x.setBounds(965, 10, 100, 20);
		x.setFont(new Font("Poppins", Font.BOLD, 20));
		frame.add(x);
		x.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		
		
		//BACK
		back.setForeground(Color.decode("#37474F"));
		back.setFont(new Font("Poppins", Font.BOLD, 17));
		back.setBounds(18, 10, 100, 20);
		frame.add(back);
		back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
			}
		});
	
		
		//Panel
		
		panel.setBounds(0, 0, 1000, 35);
		panel.setBackground(Color.decode("#FFFFFF"));
		frame.add(panel);
		
		
		//TABLE
		@SuppressWarnings("serial")
		final
		JTable table=new JTable(){
			public boolean isCellEditable(int row,int column){
				return false;
			}
		};
		model = (DefaultTableModel)table.getModel();
		model.addColumn("ID");
		model.addColumn("USERNAME");
		model.addColumn("NAME");
		updatetable();
		table.getColumnModel().getColumn(0).setPreferredWidth(50);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(2).setPreferredWidth(200);
		JScrollPane scPane=new JScrollPane(table);
		scPane.setBounds(500, 50, 480, 525);
		frame.add(scPane);
		
		
		//ID
	
		id.setFont(new Font("Poppins", Font.BOLD, 14));
		id.setFont(text);
		id.setBounds(25, 60, 40, 20);
		id.setForeground(Color.decode("#FFFFFF"));
		frame.add(id);
		final JTextField idbox= new JTextField();
		idbox.setBounds(60, 60, 50, 25);
		idbox.setBackground(Color.decode("#FFFFFF"));
		idbox.setFont(text);
		idbox.setForeground(Color.decode("#0000"));
		idbox.setEditable(false);
		frame.add(idbox);
		
		
		//USERNAME
		user.setFont(text);
		user.setBounds(25, 120, 150, 20);
		user.setForeground(Color.decode("#FFFFFF"));
		user.setFont(new Font("Poppins", Font.BOLD, 14));
		frame.add(user);
		final JTextField username= new JTextField();
		username.setBounds(25, 160, 400, 35);
		username.setBackground(Color.decode("#FFFFFF"));
		username.setFont(text);
		username.setForeground(Color.decode("#0000"));
		username.setEditable(false);
		frame.add(username);
	
		//NAME
	
		nm.setFont(new Font("Poppins", Font.BOLD, 14));
		nm.setFont(text);
		nm.setBounds(25, 240, 150, 20);
		nm.setForeground(Color.decode("#FFFFFF"));
		frame.add(nm);
		final JTextField name= new JTextField();
		name.setBounds(25, 270, 400, 35);
		name.setBackground(Color.decode("#FFFFFF"));
		name.setFont(text);
		name.setForeground(Color.decode("#0000"));
		name.setEditable(false);
		frame.add(name);
		
		
		
		//PASS
		pass.setFont(new Font("Poppins", Font.BOLD, 14));
		pass.setFont(text);
		pass.setBounds(25, 350, 150, 20);
		pass.setForeground(Color.decode("#FFFFFF"));
		frame.add(pass);
		final JPasswordField password = new JPasswordField();
		password.setBounds(25, 380, 400, 35);
		password.setBackground(Color.decode("#FFFFFF"));
		password.setFont(text);
		password.setForeground(Color.decode("#0000"));
		frame.add(password);
		
		// Password visibility toggle button
		
		togglePasswordButton.setBounds(325, 420, 100, 20);  // Adjusted the button placement
		togglePasswordButton.setFont(new Font("Poppin", Font.PLAIN, 9));
		togglePasswordButton.setBackground(Color.decode("#FFFFFF"));
		togglePasswordButton.setForeground(Color.decode("#000000"));
		frame.add(togglePasswordButton);

		// Inside your ActionListener for the togglePasswordButton
		togglePasswordButton.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        AbstractButton button = (AbstractButton) e.getSource();
		        if (button.getText().equals("Show Password")) {
		            password.setEchoChar((char) 0); // Show the password
		            togglePasswordButton.setText("Hide Password");
		        } else {
		            password.setEchoChar('\u2022'); // Hide the password
		            togglePasswordButton.setText("Show Password");
		        }
		    }
		});
		
		
		//SAVEBUTTON
		save.setBounds(60, 460, 150, 36);
		save.setFont(btn);
		save.setBackground(Color.decode("#0000"));
		save.setForeground(Color.decode("#FFFFFF"));
		save.setEnabled(false);
		frame.add(save);
		save.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent e) {
				if(check == 1) {
					try {
						adder(Integer.parseInt(idbox.getText()), username.getText(), name.getText(), password.getText());
					}
					catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
				else if(check == 2) {
					save.setEnabled(false);
					try {
						if(password.getText().equals(""))
							editor(Integer.parseInt(idbox.getText()), username.getText(), name.getText());
						else
							editor(Integer.parseInt(idbox.getText()), username.getText(), name.getText(), password.getText());
					}
					catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
				try {
					idbox.setText(String.valueOf(getid()));
					edit.setEnabled(false);
					delete.setEnabled(false);
					name.setText("");
					username.setText("");
					password.setText("");
					while(model.getRowCount() > 0)
						model.removeRow(0);
					updatetable();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		//-EDITBUTTON
		edit = new JButton("EDIT");
		edit.setBounds(60, 530, 150, 36);
		edit.setFont(btn);
		edit.setEnabled(false);
		edit.setBackground(Color.decode("#0000"));
		edit.setForeground(Color.decode("#FFFFFF"));
		frame.add(edit);
		edit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				edit.setEnabled(false);
				save.setEnabled(true);
				check = 2;
				username.setEditable(true);
				name.setEditable(true);
				password.setEditable(true);
			}
		});
		
		
		//ADDBUTTON
		add = new JButton("ADD");
		add.setBounds(250,460, 150, 36);
		add.setFont(btn);
		add.setBackground(Color.decode("#0000"));
		add.setForeground(Color.decode("#FFFFFF"));
		frame.add(add);
		add.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				add.setEnabled(false);
				save.setEnabled(true);
				delete.setEnabled(false);
				username.setEditable(true);
				name.setEditable(true);
				password.setEditable(true);
				check = 1;
				try {
					idbox.setText(String.valueOf(getid()));
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		//DELETEBUTTON
		delete = new JButton("DELETE");
		delete.setBounds(250, 530, 150, 36);
		delete.setFont(btn);
		delete.setBackground(Color.decode("#0000"));
		delete.setForeground(Color.decode("#FFFFFF"));
		delete.setEnabled(false);
		frame.add(delete);
		delete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				username.setEditable(false);
				name.setEditable(false);
				password.setEditable(false);
				edit.setEnabled(false);
				add.setEnabled(true);
				try {
					deleter(Integer.parseInt(idbox.getText()));
					idbox.setText(String.valueOf(getid()));
					name.setText("");
					username.setText("");
					password.setText("");
					while(model.getRowCount() > 0)
						model.removeRow(0);
					updatetable();
				} 
				catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		//tABLE ACTION
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				password.setText("");
				idbox.setText(String.valueOf(table.getModel().getValueAt(row, 0)));
				username.setText(String.valueOf(table.getModel().getValueAt(row, 1)));
				name.setText(String.valueOf(table.getModel().getValueAt(row, 2)));
				edit.setEnabled(true);
				username.setEditable(false);
				password.setEditable(false);
				name.setEditable(false);
				save.setEnabled(false);
				delete.setEnabled(true);
			}
		});
		
		frame.setSize(1000,600);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setUndecorated(true);
		frame.setLocationRelativeTo(null);  
		frame.setVisible(true);
		frame.setFocusable(true);
		frame.getContentPane().setBackground(Color.decode("#25CEDE"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public void updatetable() {
		try {
			ResultSet res = dbSearch();
			for(int i=0; res.next(); i++) {
				model.addRow(new Object[0]);
				model.setValueAt(res.getInt("id"), i, 0);
		        model.setValueAt(res.getString("username"), i, 1);
		        model.setValueAt(res.getString("name"), i, 2);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}
	
	public ResultSet dbSearch() throws SQLException {
		//ENTER PORT, USER, PASSWORD.
		String str1 = "SELECT * FROM user WHERE prio = 1";
		String url = "jdbc:mysql://localhost:3306/attendance";
		String user = "root";
		String pass = "alishka";
		con = DriverManager.getConnection(url, user, pass);
		Statement stm = con.createStatement();
		ResultSet rst = stm.executeQuery(str1);
		return rst;
	}
	
	public int getid() throws SQLException {
        Statement stm = con.createStatement();
        ResultSet rst = stm.executeQuery("SELECT MAX(id) from user");
        if(rst.next()) {
            return rst.getInt("MAX(id)")+1;
        }
        else {
            return 1;
        }
    }
	
	public void adder(int id, String user, String name, String password) throws SQLException {
		String adding = "insert into user values ("+id+", '"+user+"', '"+name+"', '"+password+"', 1)";
        Statement stm = con.createStatement();
        stm.executeUpdate(adding);
	}
	
	public void deleter(int id) throws SQLException {
		String del = "DELETE FROM user WHERE id = "+id;
        Statement stm = con.createStatement();
        stm.executeUpdate(del);
	}
	public void editor(int id, String username, String name, String password) throws SQLException {
		String update = "UPDATE user SET username = '"+username+"', name = '"+name+"', password = '"+password+"'WHERE id = "+id;
        Statement stm = con.createStatement();
        stm.executeUpdate(update);
	}
	public void editor(int id, String username, String name) throws SQLException {
		String update = "UPDATE user SET username = '"+username+"', name = '"+name+"' WHERE id = "+id;
        Statement stm = con.createStatement();
        stm.executeUpdate(update);
	}
}
