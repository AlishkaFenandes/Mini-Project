package Attendance;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.AbstractButton;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicButtonUI;

import java.sql.*;

public class Login extends Common{
	
	int usr = 0;
	public void loginView() {
		final JFrame frame = new JFrame();
		Font text = new Font("Poppins", Font.PLAIN, 20);
		final Home name = new Home();
		final TeacherView teacherView = new TeacherView();
		final StudentView studentView = new StudentView();
		
	
		
		//CLOSE
		x.setForeground(Color.decode("#FFFFFF"));
		x.setBounds(965, 20, 100, 20);
		x.setFont(new Font("Poppins", Font.BOLD, 20));
		frame.add(x);
		x.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		
		
		
		
		//LOGINTEXT
		JLabel lgn = new JLabel("WELCOME");
		lgn.setBounds(420, 80, 200, 100);
		lgn.setForeground(Color.decode("#0000"));
		lgn.setFont(new Font("Poppin", Font.BOLD, 30));
		frame.add(lgn);
		
	
		
		//USER
		user.setForeground(Color.decode("#FFFFFF"));
		user.setBounds(320, 220, 100, 20);
		user.setFont(text);
		user.setFont(new Font("Poppins", Font.BOLD, 15));
		frame.add(user);
	
		
		//USERFIELD
		final JTextField username = new JTextField();
		username.setBounds(320, 255, 360, 35);
		username.setBackground(Color.decode("#FFFFFF"));
		username.setForeground(Color.decode("#37474F"));
		username.setFont(new Font("Poppins", Font.BOLD, 15));
		frame.add(username);
		
		
		//Password
		JLabel passLabel = new JLabel("Password");
		passLabel.setForeground(Color.decode("#FFFFFF"));
		passLabel.setBounds(320, 320, 100, 20);
		passLabel.setFont(text);
		passLabel.setFont(new Font("Poppins", Font.BOLD, 15));
		frame.add(passLabel);

		//PASSWORDFIELD
		final JPasswordField password = new JPasswordField();
		password.setBounds(320, 355, 360, 35);
		password.setBackground(Color.decode("#FFFFFF"));
		password.setForeground(Color.decode("#37474F"));
		frame.add(password);

		//PASSWORD VISIBILITY TOGGLE BUTTON
		final JButton togglePasswordButton = new JButton("Show Password");
		togglePasswordButton.setBounds(580, 400, 100, 20);  // Adjusted the button placement
		togglePasswordButton.setFont(new Font("Poppin", Font.PLAIN, 9));
		togglePasswordButton.setBackground(Color.decode("#FFFFFF"));
		togglePasswordButton.setForeground(Color.decode("#000000"));
		frame.add(togglePasswordButton);

		// togglePasswordButton
		togglePasswordButton.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        AbstractButton button = (AbstractButton) e.getSource();
		        if (button.getText().equals("Show Password")) {
		            password.setEchoChar((char) 0); // Show the password
		            togglePasswordButton.setText("Hide Password");
		        } else {
		            password.setEchoChar('\u2022'); // Hide the password
		            togglePasswordButton.setText("Show Password");
		        }
		    }
		});



		//-WARNING
		final JLabel warning = new JLabel();
		warning.setForeground(Color.RED);
		warning.setBounds(380, 430, 250, 20);
		warning.setHorizontalAlignment(warning.CENTER);
		frame.add(warning);
		
		
		JButton login = new JButton("LOG IN");
		login.setBounds(380, 480, 250, 50);
		login.setFont(new Font("Poppins", Font.BOLD, 16));
		login.setBackground(Color.decode("#000000"));
		login.setForeground(Color.decode("#FFFFFF"));
		frame.add(login);
		
		
		login.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int res = dbCheck(username.getText(), password.getText());
					if(res == 0) {
						warning.setText("NO USER FOUND!!!");
						username.setText("");
						password.setText("");
					}
					else if(res == -1) {
						warning.setText("WRONG PASSWORD!!!");
						username.setText("");
						password.setText("");
					}
					else {
						if(res == 1)
							name.homeView(usr);
						else if(res == 2)
							teacherView.tcView(usr);
						else if (res == 3)
							studentView.stView(usr);
						frame.dispose();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		frame.setSize(1000,600);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setUndecorated(true);
		frame.setLocationRelativeTo(null);  
		frame.setVisible(true);
		frame.setFocusable(true);
		frame.getContentPane().setBackground(Color.decode("#25CEDE"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public int dbCheck(String name, String password) throws SQLException {
		String url = "jdbc:mysql://localhost:3306/attendance";
		String user = "root";
		String pass = "alishka";
		String str = "SELECT * FROM user WHERE username = '" + name + "'";
		Connection con = DriverManager.getConnection(url, user, pass);
		Statement stm = con.createStatement();
		ResultSet rst = stm.executeQuery(str);
		if(rst.next()) {
			if(rst.getString("password").equals(password)) {
				usr = rst.getInt("id");
				return rst.getInt("prio");
			}
			else
				return -1;
		}
		else {
			return 0;
		}
	}
}